export const environment = {
  production: true,
  model_api:'https://text2query.azurewebsites.net/api/text/text2sql?promt=${query}'
};